#!/bin/bash

echo "🚀 Installing PDF Filler MCP Server..."
npm install
echo "✅ Dependencies installed!"
echo ""

# Get the absolute path automatically
FULL_PATH="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/server/index.js"
MCP_CONFIG="$HOME/.cursor/mcp.json"

echo "✨ Detected server path: $FULL_PATH"
echo ""

# Check if mcp.json exists
if [ -f "$MCP_CONFIG" ]; then
    echo "📂 Found existing MCP config at: $MCP_CONFIG"
    echo ""
    echo "🤖 Would you like me to automatically add pdf-filler to your config? (y/n)"
    read -r response
    
    if [[ "$response" =~ ^[Yy]$ ]]; then
        # Create backup
        cp "$MCP_CONFIG" "$MCP_CONFIG.backup"
        echo "💾 Backup created: $MCP_CONFIG.backup"
        
        # Check if pdf-filler already exists
        if grep -q '"pdf-filler"' "$MCP_CONFIG"; then
            echo "⚠️  pdf-filler already exists in config. Skipping auto-update."
        else
            # Use python to safely update JSON
            python3 -c "
import json
import sys

try:
    with open('$MCP_CONFIG', 'r') as f:
        config = json.load(f)
    
    if 'mcpServers' not in config:
        config['mcpServers'] = {}
    
    config['mcpServers']['pdf-filler'] = {
        'command': 'node',
        'args': ['$FULL_PATH']
    }
    
    with open('$MCP_CONFIG', 'w') as f:
        json.dump(config, f, indent=2)
    
    print('✅ Successfully added pdf-filler to MCP config!')
except Exception as e:
    print(f'❌ Error updating config: {e}')
    sys.exit(1)
"
            if [ $? -eq 0 ]; then
                echo ""
                echo "🎉 DONE! pdf-filler has been added to your MCP config!"
                echo ""
                echo "🔄 Next steps:"
                echo "1. Completely quit Cursor"
                echo "2. Restart Cursor"
                echo "3. Look for 'pdf-filler' showing '10 tools enabled'"
                echo ""
                echo "🎯 You're all set! No manual copying needed!"
            else
                echo "⚠️  Auto-update failed. Please use manual method below."
                show_manual_instructions
            fi
        fi
    else
        show_manual_instructions
    fi
else
    echo "📂 No existing MCP config found. Creating new one..."
    mkdir -p "$(dirname "$MCP_CONFIG")"
    
    cat > "$MCP_CONFIG" << EOF
{
  "mcpServers": {
    "pdf-filler": {
      "command": "node",
      "args": ["$FULL_PATH"]
    }
  }
}
EOF
    
    echo "✅ Created new MCP config with pdf-filler!"
    echo ""
    echo "🔄 Next steps:"
    echo "1. Completely quit Cursor"
    echo "2. Restart Cursor"
    echo "3. Look for 'pdf-filler' showing '10 tools enabled'"
fi

function show_manual_instructions() {
    echo ""
    echo "📋 MANUAL METHOD - Copy this exact text to ~/.cursor/mcp.json:"
    echo ""
    echo "==============================================="
    echo '{'
    echo '  "mcpServers": {'
    echo '    "pdf-filler": {'
    echo '      "command": "node",'
    echo "      \"args\": [\"$FULL_PATH\"]"
    echo '    }'
    echo '  }'
    echo '}'
    echo "==============================================="
    echo ""
    echo "💡 To open the file: open ~/.cursor/mcp.json"
} 